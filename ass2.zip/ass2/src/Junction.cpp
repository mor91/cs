/* 
 * File:   Junction.cpp
 * Author: chen
 * 
 * Created on November 15, 2014, 1:36 PM
 */

#include "Junction.h"

Junction::Junction() {
}

Junction::Junction(const std::string &junctionID) {
    _junctionID=junctionID;
}

Junction::~Junction() {
}

