/* 
 * File:   Report.cpp
 * Author: chen
 * 
 * Created on November 15, 2014, 11:45 AM
 */

#include "Report.h"

Report::Report() {
}

Report::Report(const std::string &reportID) {
    _reportID=reportID;
}

Report::~Report() {
}

