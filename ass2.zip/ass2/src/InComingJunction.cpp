#include "../include/InComingJunction.h"


InComingJunction::InComingJunction(){

}
InComingJunction::InComingJunction(const Junction& junction, int timeSlice){

}
InComingJunction::~InComingJunction(){

}
void newTimeSlice(){
	int newTimeSlice;

	_timeSlice=newTimeSlice;
}
