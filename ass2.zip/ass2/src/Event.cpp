/* 
 * File:   Event.cpp
 * Author: chen
 * 
 * Created on November 15, 2014, 11:43 AM
 */

#include "Event.h"

Event::Event() {
}

Event::Event(const std::string &eventID) {
    _eventID=eventID;
}

Event::~Event() {
}


