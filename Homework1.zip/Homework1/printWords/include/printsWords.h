#ifndef PRINTWORDS_H_
#define PRINTWORDS_H_

#include <vector>
#include <string>
#include <iostream>

string from10to2();   // This is a free function declaration
 
#endif