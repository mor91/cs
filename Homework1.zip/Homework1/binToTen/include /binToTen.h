#ifndef BINTOTEN_H_
#define BINTOTEN_H_
#include <iostream>
#include <string>
string from10to2();   // This is a free function declaration
 
#endif